package splaytree.core;

public enum Side {
    LEFT, RIGHT;
}
