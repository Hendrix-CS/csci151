package maze.model.searchers;

import maze.searchers.Stack;

public class ArrayStack<E> implements Stack<E> {

	private int top;
	private E[] stuff;

	public ArrayStack() {
		this(8);
	}

	public ArrayStack(int initialSize) {
		stuff = (E[])(new Object[initialSize]);
		top = 0;
	}

	@Override
	public int size() {
		// TODO Step 1 Implement ArrayStack
		return 0;
	}

	@Override
	public E pop() {
		// TODO Step 1 Implement ArrayStack
		return null;
	}

	@Override
	public E peek() {
		// TODO Step 1 Implement ArrayStack
		return null;
	}

	@Override
	public void push(E e) {
		// TODO Step 1 Implement ArrayStack
	}

	@Override
	public String toString() {
		String s = "";
		for (int i = 0; i <= top; i++) {
			s += stuff[i] + " ";
		}
		return s;
	}

	@Override
	public int capacity() {
		return stuff.length;
	}
}
