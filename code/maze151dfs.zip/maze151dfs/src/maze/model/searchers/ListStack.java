package maze.model.searchers;

import maze.searchers.Stack;

public class ListStack<E> implements Stack<E> {

    // TODO Step 2 Add private Node for top

    @Override
    public int size() {
        // TODO Step 2 Implement ListStack
        return 0;
    }

    @Override
    public int capacity() {
        // TODO Step 2 Implement ListStack
        return 0;
    }

    @Override
    public E pop() {
        // TODO Step 2 Implement ListStack
        return null;
    }

    @Override
    public void push(E data) {
        // TODO Step 2 Implement ListStack

    }

    @Override
    public E peek() {
        // TODO Step 2 Implement ListStack
        return null;
    }

    @Override
    public String toString() {
        // TODO Step 2 Implement ListStack
        return "";
    }
}
