module maze151 {
    requires javafx.fxml;
    requires javafx.controls;
    requires junit;

    opens maze.gui;
}