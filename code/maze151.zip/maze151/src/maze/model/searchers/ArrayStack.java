package maze.model.searchers;

import maze.searchers.Stack;

public class ArrayStack<E> implements Stack<E> {

	private int top;
	private E[] stuff;

	public ArrayStack() {
		this(8);
	}

	public ArrayStack(int initialSize) {
		top = -1;
		stuff = (E[])(new Object[initialSize]);
	}

	@Override
	public int size() {
		return top + 1;
	}

	@Override
	public E pop() {
		emptyCheck();
		E temp = stuff[top];
		top--;
		return temp;
	}

	@Override
	public E peek() {
		emptyCheck();
		return stuff[top];
	}

	@Override
	public void push(E e) {
		resize();
		top++;
		stuff[top] = e;
	}

	private void resize() {
		if (top == stuff.length - 1) {
			E[] stuff2 = (E[])(new Object[stuff.length * 2]);
			for (int i = 0; i < stuff.length; i++) {
				stuff2[i] = stuff[i];
			}
			stuff = stuff2;
		}
	}

	@Override
	public String toString() {
		String s = "";
		for (int i = 0; i <= top; i++) {
			s += stuff[i] + " ";
		}
		return s;
	}

	@Override
	public int capacity() {
		// TODO Auto-generated method stub
		return stuff.length;
	}
}
