package specs;

public record Score(int one, int two) {

}
