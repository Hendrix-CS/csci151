package specs;

public class Score {
	private int one, two;
	
	public Score(int one, int two) {
		this.one = one;
		this.two = two;
	}
	
	public int getOne() {return one;}
	public int getTwo() {return two;}
}
