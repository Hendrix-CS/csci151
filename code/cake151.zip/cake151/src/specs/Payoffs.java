package specs;

public interface Payoffs {
	public Score score(boolean askForAll1, boolean askForAll2);
}
