package demo;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

public class DemoController {

	@FXML
	private Pane pane;

	private ArrayList<Piece> pieces;

	private Rectangle[][] squares;

	private int size = 200;
	private int spots = 20;
	private int squaresize = size / spots;

	@FXML
	public void initialize() {
		pieces = new ArrayList<Piece>();
		squares = new Rectangle[spots][spots];

		for (int i = 0; i < size; i += squaresize) {
			for (int j = 0; j < size; j += squaresize) {
				Rectangle r = new Rectangle(i, j, squaresize, squaresize);
				squares[i / squaresize][j / squaresize] = r;
				r.setFill(Color.WHITE);
				r.setStroke(Color.BLACK);
				pane.getChildren().add(r);
			}
		}

		for (int i = 0; i < 5; i++) {
			makePiece();
		}
	}

	private void makePiece() {
		Circle c = new Circle();
		c.setFill(Color.GREEN);
		c.setStroke(Color.BLACK);
		double radius = squaresize / 3.0;
		int x = squaresize / 2 + squaresize * (int)(Math.random() * spots);
		int y = squaresize / 2 + squaresize * (int)(Math.random() * spots);
		Piece p = new Piece(x, y, radius, c);
		c.setOnMouseDragged(event -> drag(event, p));
		c.setOnMousePressed(event -> pressed(event, p));
		c.setOnMouseReleased(event -> released(event, p));
		pieces.add(p);
		pane.getChildren().add(c);
		p.draw();
	}

	// What to do when the mouse is Pressed
	private void pressed(MouseEvent event, Piece b) {
		b.setColor(Color.DARKRED);
	}

	// What to do when the mouse is Released
	private void released(MouseEvent event, Piece b) {
		int gridx = (int)b.getX() / squaresize;
		int gridy = (int)b.getY() / squaresize;
        squares[gridx][gridy].setFill(Color.LIGHTGREEN);
		b.setX(squaresize / 2 + squaresize * gridx);
		b.setY(squaresize / 2 + squaresize * gridy);
		b.setColor(Color.DODGERBLUE);
		b.draw();
	}

	// What to do when the mouse is Dragged
	private void drag(MouseEvent event, Piece b) {
		b.setX(b.getX() + event.getX());
		b.setY(b.getY() + event.getY());
		b.draw();
	}
}
