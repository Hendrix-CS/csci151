package maze.searchers;

public class ListQueue<E> implements Queue<E> {

    // TODO Step 1.1 Add fields

    @Override
    public void add(E data) {
        // TODO Step 1.2
    }

    @Override
    public E remove() {
        // TODO Step 1.3
        return null;
    }

    @Override
    public E element() {
        // TODO Step 1.4
        return null;
    }
    @Override
    public int size() {
        // TODO Step 1.5
        return 0;
    }

    @Override
    public int capacity() {
        return size();
    }

}
