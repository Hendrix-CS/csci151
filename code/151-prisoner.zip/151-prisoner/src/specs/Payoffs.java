package specs;

public interface Payoffs {
	public Score score(boolean defect1, boolean defect2);
}
