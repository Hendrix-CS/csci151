My engine adds on a few different features.
It allows locations to have characters that the player can converse
with. The dialog options allow the player to move through a tree of
the character's lines by choosing responses. Some responses will be
locked off based on the contents of the player's inventory and the
initial line of a character can change based on the player's choices.

It allows items to have special actions that can be used on other
items. An item can either cause the target item to be removed from
the world or cause the target to give the player an item.

Certain items can act as roadblocks, preventing the player from moving
in a certain direction until they are cleared.

Some locations require the player to have a certain item before the
player can enter them.

It is also possible to end the game by setting an exit in a location
to end. The game will print out an ending message and then end when
the player goes through that exit.

Woods.yml is a simple world that showcases the features I added to
my engine. The player must use items and talk to a character in order
to find the way out of the woods.