Explore your surroundings. You can get points by taking certain objects to certain other locations.
Be careful, things have weight. Once you pick up too many items, you wont be able to move.
Available commands:
go <dir>        - move in a certain direction
look            - look at your surroundings
look <dir>      - see what location lies in a given direction
look [at] <obj> - look at an object in your location or inventory
take <obj>      - pick up an object
drop <obj>      - put down an object
inventory       - see what you are carrying
score           - see your current score
help            - show this help message
quit            - quit

Available directions:
north south east west northeast northwest southeast southwest up down in out

Enjoy the game!