I created a yml file for part of the first floor of Veasey.
I also added a way to interact with characters. To interact,
you use the talk command. Characters will either have a message
or a question. In the yml file I created, messages from characters
give hints about specific items they want to be dropped in
their location, and if you succeed you earn points. You also
earn points if you correctly answer a characters question
(you only have one chance to answer correctly.)