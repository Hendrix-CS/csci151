The main special feature I included in my Game.yml file was the addition of a gun that allows you to do a
special action and it even saves your life if you use it in a certain room. I also included an ammo system
to make the gun more limited. Other than that, the basis of my project is pretty simple.