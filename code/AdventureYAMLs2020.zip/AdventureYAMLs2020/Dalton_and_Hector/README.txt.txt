For our expert implementation, we created an item (the sword)
that requires a certain amount of score to attain. By retrieving
items for the Toads scattered across the map, you get more 
points that go towards your score. Without the sword,you cannot 
pass through a certain region in the map. This region
cannot be traversed without the sword being in your inventory and 
so it serves as a blocker for the player. 