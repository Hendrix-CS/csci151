My engine includes the ability to defeat monsters that are located on the map. 
Monsters do not attack, but require a minimum level of score to defeat, and reward score upon their death.
When you reach 100 score on a map, you win. On my map, 100 is the maximum score possible, so all tasks must be completed.
Part of my code mentions "locked" locations, which would unlock if an item with the "unlock" field was brought to it. 
This code does not have a function in this version of the project though.
