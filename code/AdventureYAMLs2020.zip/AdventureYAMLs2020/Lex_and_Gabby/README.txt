Our engine includes all of the features listed in the lab criteria. For our
addition we chose to include an additional point system known as "play points"
that occur when the environment is interacted or "played" with. There is also a
new action verb PLAY to help implement this.
Our YML takes place predominantly in the school yard with one only one location
actually being the school classroom (end of game destination.
There is a conditional object added which is the apple and that is coded in our
engine but not part of the standard engine.
The apple can only be accessed after taking the ball to the kid by the fence.
The map was inspired by the fact that we are in a literal pandemic and are all
trapped inside and dream of the outside world without a deadly disease being
on the loose.
Enjoy the funny descriptions.
- Lex and Gabby