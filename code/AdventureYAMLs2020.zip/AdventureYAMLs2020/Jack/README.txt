For this project I created an engine that would run through the game Adventure, if given a world in a .yml file.
 There are multiple commands that can be found within the engine while running, these can be found with the help command.

A special feature I added was an alarm system. This can only be activated if the world has an escape pod, labeled with the
"id" of "escp". When the alarm in set off every little thing counts, even the help command counts towards a move. So if
there is an acceptible reason to set off the alarm, you better make everything you do count.

I thought this was a pretty neat feature since the map I created was a space station, so an escape pod might be very
essential.

The world I created was a space station, throughout the space station there is certain areas with windows you can look out
to see what is in that direction in space, which could be really beautiful like Earth, or just nothing.

Thank you for your time!

~ Jack Hodgins