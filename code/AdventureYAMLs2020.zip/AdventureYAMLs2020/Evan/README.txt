This is the readme for the WernerAdventure yaml file. The story of the game is that you are at your parent's house, and
in the middle of the night you hear screaming, which you go investigate. The goal is to not only find the source of the
screaming, but to also bring the necessary medical supplies to the source, along with a way to call the ambulance.
To move in the game you type in go direction. The directions available are NORTH, SOUTH, EAST, WEST, NORTHEAST,
NORTHWEST, SOUTHEAST, SOUTHWEST, UP, DOWN, IN, OUT, and UNKNOWN. You can find the available directions to use within a
given room by reading the initial description of the room. The same is true for knowing what items are in a room, which
you can take by typing take item. Sometimes you won't be able to take an item from its lack of portability. Typing
inventory will print out a list of current items in your inventory. You remove items from your inventory by typing
drop item.  The look command can either by given an item (look at item) which will print its description, or it can be
generic which will instead print the initial description of the room. Typing score will show you your current score,
which can be raised by dropping an item at its goal location.