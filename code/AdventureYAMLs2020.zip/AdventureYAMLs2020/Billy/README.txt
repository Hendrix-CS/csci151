Copyright @ Billy Hayes
-------------------------------------------------------------------------------

ENGINE DESCRIPTION: 

This engine allows a user to implement a text adventure
given an appropriate Yaml file. The user can move a character through different
locations. The character can also interact with items in the environment and
perform a number of actions. Typing in "help" will allow the user to see the 
actions they can take to interact with the world.

-------------------------------------------------------------------------------

YAML FILE: BillysHouse

A real layout of my house! A picture is attached for ease of navigation.

-------------------------------------------------------------------------------

SPECIAL FEATURES: 

In addition to the features included in the original Hendrix map traversal, the 
user now has to worry about how daunting a task may be. A user can only 
overcome their fear with the right amount of gamer strength. The only way to 
gain gamer strength is with the right gamer substance: energy drinks. 
Unfortunately, Rosie has consumed most of the house's stash of energy drinks. 
The user can now search the house for and drink energy drinks to 
build the gamer strength needed to accomplish even the boldest acts.

Look for:
The Drink action
Intimidation checks
How gamer strength affects the player's opportunities

-------------------------------------------------------------------------------