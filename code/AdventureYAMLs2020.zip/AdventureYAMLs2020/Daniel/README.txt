My expert extension is a creature in the Bowling Alley on the second floor.
If the player doesn't have a certain item, then the creature will kill the player
and it quits the game. Otherwise it does the long description of the room like 
normal.