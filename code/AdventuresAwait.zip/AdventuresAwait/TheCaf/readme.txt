Julia Dick, Kaden Franklin, Matthew Haley

Our engine includes all of the functions up to the advanced level of the lab. We also included an extra weight function. 
A player can only carry up to 4 weight. If they try to pick up anything else they will get a message saying "You are already carrying too much."

For our extra .yml file we made the hendrix Caf. You can walk around to all of the different stations in the caf, 
and get all of the food you have been wanting to eat since march. We have also included all of the workers who can usually be found at each corresponding location.