package adventure;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import org.yaml.snakeyaml.Yaml;

/**
 * This class demonstrates how to read a YAML file using the SnakeYAML library
 * and process the resulting objects. It also demonstrates the use of the
 * Command class.
 *
 * <p>
 * Copyright 2017 Brent Yorgey. This work is licensed under a
 * <a rel="license" href= "http://creativecommons.org/licenses/by/4.0/">Creative
 * Commons Attribution 4.0 International License</a>.
 * </p>
 *
 * @author Brent Yorgey
 * @version August 21, 2017
 *
 */
public class AdventureDemo {

	public static void main(String[] args) {

		// If anything goes wrong inside the 'try' (e.g. the file is not found),
		// it will jump to the 'catch' part.
		try {

			InputStream input = new FileInputStream(new File("Zoo.yml"));

			// Create a Yaml object to parse the .yaml file
			Yaml yaml = new Yaml();

			// Save locations from the YAML file
			Map<String, Object> places = new HashMap<String, Object>();

			Map<String, Object> here = null;

			List<Map<String, Object>> inventory = new ArrayList<Map<String, Object>>();

			boolean first = true;

			ArrayList<String> visited = new ArrayList<String>();

			int score = 0;

			ArrayList<String> unlocked_exits = null;


			// Parse the .yaml file and loop over the resulting objects.
			for (Object thing : yaml.loadAll(input)) {

				// We happen to know that the YAML file contains key-value
				// mappings, so the returned Objects will in fact be Maps, and
				// we can cast them as such. Eclipse shows us a warning here
				// (yellow underline) because this code might crash if we call
				// it on the wrong sort of .yaml file and 'thing' is not
				// actually a Map.
				Map<String, Object> location = ((Map<String, Object>) thing);
				places.put((String)location.get("id"), location);

				if(first){
					here = location;
					first = false;
				}
			}

			printItems(here, false);

			Scanner in = new Scanner(System.in);
			Command com;

			do {
				if (!visited.contains(here.get("id").toString().toLowerCase())) {
					visited.add((String) here.get("id").toString().toLowerCase());
				}


				// Read the user's input and parse it using a Command object.
				com = new Command(in.nextLine());

				// Now we can query the Command object to find out what the user
				// typed. This example only pays attention to the verb (the
				// first word typed).
				if (com.getVerb().equals(Verb.UNKNOWN)) {
					System.out.println("What?");
				} else {
					System.out.println("");
					System.out.println("OK, you want to " + com.getVerb() + ".");

					if (com.getVerb() == Verb.GO){

						// direction is valid
							// room has no lock *
							// room has lock
								// room is locked
									// has blocked exits
										//direction is blocked
										//direction is unblocked *
									// has no blocked exits *
								// room is unlocked *

						Map<String, Object> exits = (Map<String, Object>) here.get("exits");

						String newID = (String)exits.get(com.getDirection().toString().toLowerCase());

						// if direction is valid
						if (newID != null) {
							// if there is a lock
							if (checkLock(here)){
								//if the room is unlocked
								if (isUnlocked(here)){
									if (places.containsKey(newID)){
										here = (Map<String, Object>) places.get(newID);
										printItems(here, visited.contains(here.get("id").toString().toLowerCase()));
									} else {
										System.out.println("That place looks hazy. You avoid it and stay here.");
									}
								// if the room is locked
								} else {
									// if the room has blocked exits
									if (here.get("unlocked_exits") != null) {

										unlocked_exits = (ArrayList<String>) here.get("unlocked_exits");

										// if the direction is one of the unblocked exits
										if (unlocked_exits.contains(com.getDirection().toString().toLowerCase())){
											if (places.containsKey(newID)){
												here = (Map<String, Object>) places.get(newID);
												printItems(here, visited.contains(here.get("id").toString().toLowerCase()));
											} else {
												System.out.println("That place looks hazy. You avoid it and stay here.");
											}
										// if direction is blocked
										} else {
											System.out.println("That way is blocked");
										}
									// if the room is locked, but has no blocked exits
									} else {
										if (places.containsKey(newID)){
											here = (Map<String, Object>) places.get(newID);
											printItems(here, visited.contains(here.get("id").toString().toLowerCase()));
										} else {
											System.out.println("That place looks hazy. You avoid it and stay here.");
										}
									}
								}
							// if there is no lock
							} else {
								if (places.containsKey(newID)){
									here = (Map<String, Object>) places.get(newID);
									printItems(here, visited.contains(here.get("id").toString().toLowerCase()));
								} else {
									System.out.println("That place looks hazy. You avoid it and stay here.");
								}
							}
						} else {
							System.out.println("You can't go that way");
						}

					} else if (com.getVerb() == Verb.TAKE){

						ArrayList<Map<String, Object>> itemList = (ArrayList<Map<String, Object>>) here.get("items");

						Map<String, Object> item = findItem(itemList, com.getNoun());

						//if item is here
						if(item != null) {
							// if the room is locked
							if (checkLock(here)){
								//if there is a locked item in the room
								if(!isUnlocked(here) && here.get("locked_item") != null) {
									if (here.get("locked_item").toString().equals(com.getNoun())) {
										System.out.println("You cannot take that item yet.");
									}
								// if there are no locked items in a locked room
								} else {
									if (item.get("portable") == null) {
										itemList.remove(item);
										inventory.add(item);
										System.out.println("Took " + com.getNoun() + ".");
									} else {
										System.out.println("You cannot take that");
									}
								}
							// if the room is not locked
							} else {
								if (item.get("portable") == null) {
									itemList.remove(item);
									inventory.add(item);
									System.out.println("Took " + com.getNoun() + ".");
								} else {
									System.out.println("You cannot take that");
								}
							}
						} else {
							System.out.println("There is no "+com.getNoun() + " here.");
						}


					} else if (com.getVerb() == Verb.INVENTORY){
						if (inventory.size() > 0){
							for(Map<String, Object> itemAttributes : inventory){
								System.out.println(itemAttributes.get("name"));
							}
						} else {
							System.out.println("You have no items.");
						}


					} else if (com.getVerb() == Verb.DROP){
						Map<String, Object> item = findItem(inventory, com.getNoun());

						if(item != null){
							inventory.remove(item);
							List<Map<String, Object>> itemList = (List<Map<String, Object>>) here.get("items");

							if (itemList == null){
								itemList = new ArrayList<Map<String, Object>>();
								here.put("items", itemList);
							}
							itemList.add(item);

							if (item.get("goal") != null) {
								if (here.get("id").toString().toLowerCase().equals(item.get("goal").toString().toLowerCase())) {
									score += (int) item.get("score");
									System.out.println(item.get("goalmessage"));
									System.out.println("You gained " + item.get("score") + " points!");
								}
							}

						} else {
							System.out.println("You don't have a " + com.getNoun());
						}


					} else if (com.getVerb() == Verb.SCORE){
						System.out.println("Your score is " + score + ".");


					} else if (com.getVerb() == Verb.LOOK){

						// looking at an item
						if (com.getNoun() != "") {
							List<Map<String, Object>> itemList = (List<Map<String, Object>>) here.get("items");

							// if is in location
							if (findItem(itemList, com.getNoun()) != null) {

								// if the location has a locked desc
								if (checkLock(here) && findItem(itemList, com.getNoun()).get("locked_desc") != null){

									if(isUnlocked(here)){
										System.out.println(findItem(itemList, com.getNoun()).get("desc"));
									} else {
										System.out.println(findItem(itemList, com.getNoun()).get("locked_desc"));
									}
								} else {
									System.out.println(findItem(itemList, com.getNoun()).get("desc"));
								}

							// if the item is in inventory
							} else if (findItem(inventory, com.getNoun()) != null) {
								System.out.println(findItem(inventory, com.getNoun()).get("desc"));

							// if item is in neither inventory or location
							} else {
								System.out.println("There is no " + com.getNoun() + " here.");
							}

						} else if (com.getDirection() != Direction.UNKNOWN){
							//check to see if valid
							//print the name
							Map<String, Object> exits = (Map<String, Object>) here.get("exits");

							String newID = (String)exits.get(com.getDirection().toString().toLowerCase());
							Map<String, Object> lookAt = (Map<String, Object>)places.get(newID);


							if (newID != null && lookAt != null){
								if (lookAt.get("article") != null){
									System.out.println("You can see " + lookAt.get("article").toString().toLowerCase() + " " + lookAt.get("name") + " in that direction.");
								} else {
									System.out.println("You can see " + lookAt.get("name") + " in that direction.");
								}
							} else if (newID != null && lookAt == null){
								System.out.println("The location in that direction looks hazy.");
							} else {
								System.out.println("There's nothing to see in that direction.");
							}

						} else {
							if (checkLock(here)){
								if (isUnlocked(here)){
									System.out.println(here.get("longdesc"));
								} else {
									System.out.println(here.get("locked_longdesc"));
								}
							} else {
								System.out.println(here.get("longdesc"));
							}
						}

					} else if (com.getVerb() == Verb.HELP){
						System.out.println("");
						System.out.println("Explore your surroundings.  You can get points by feeding hungry");
						System.out.println("animals their favorite food.");
						System.out.println("");
						System.out.println("		Available commands:");
						System.out.println("go <dir>        - move in a certain direction");
						System.out.println("look            - look at your surroundings");
						System.out.println("look <dir>      - see what location lies in a given direction");
						System.out.println("look [at] <obj> - look at an object in your location or inventory");
						System.out.println("take <obj>      - pick up an object");
						System.out.println("drop <obj>      - put down an object");
						System.out.println("inventory       - see what you are carrying");
						System.out.println("score           - see your current score");
						System.out.println("help            - show this help message");
						System.out.println("quit            - quit");
						System.out.println("");
						System.out.println("Available directions:");
						System.out.println("north south east west northeast northwest southeast southwest up down in out");
						System.out.println("");
					}

				}
			} while (com.getVerb() != Verb.QUIT);

			in.close();

		} catch (IOException e) {
			// This is what to do if anything goes wrong, e.g. the file
			// Hendrix.yaml is not found. Just print the error and quit.
			System.out.println(e);
			System.exit(1);
		}
	}

	private static Map<String, Object> findItem(List<Map<String, Object>> itemList, String what){
		if (itemList != null){
			for (Map<String, Object> itemAttributes : itemList) {
				if (((String)itemAttributes.get("name")).toLowerCase().equals(what.toLowerCase()) ||
						(itemAttributes.get("aliases") != null && itemAttributes.get("aliases").toString().toLowerCase().contains(what.toLowerCase()))) {
					return itemAttributes;
				}
			}
		}
		return null;
	}


	/**
	 * Take a key-value mapping representing a location in the world. Look
	 * through it and print any items it contains.
	 *
	 * @param location
	 *            The key-value mapping representing the location.
	 */
	private static void printItems(Map<String, Object> location, boolean visited) {

		// 6 possibilities:
		// locked visited
		// locked unvisited
		// unlocked visited
		// unlocked unvisited
		// no lock visited
		// no lock unvisited

		if (visited){
			if (checkLock(location)){
				if (isUnlocked(location)){
					System.out.println(location.get("desc"));
				} else {
					System.out.println(location.get("locked_desc"));
				}
			} else {
				System.out.println(location.get("desc"));
			}
		} else {
			if(checkLock(location)){
				System.out.println(location.get("locked_longdesc"));
			} else {
				System.out.println(location.get("longdesc"));
			}
		}

		// Extract the list of items, which is stored under the key "items".
		// Each item is itself a key-value mapping.
		List<Map<String, Object>> itemList = (List<Map<String, Object>>) location.get("items");

		// If the location does not have a key called "items", then the call to
		// get("items") above will return null.

		if (itemList == null) {
			System.out.println("Location " + location.get("name") + " has no items.");
		} else {

			// For each item, get the values associated to the keys "name" and
			// "portable".
			for (Map<String, Object> item : itemList) {
				if (item.get("portable") == null){
					if(item.get("key") == null) {
						System.out.println("  There is a " + item.get("name") + " here.");
					} else {
						if (checkLock(location)){
							if (!isUnlocked(location)){
								System.out.println("  There is a " + item.get("name") + " here.");
							}
						} else {
							System.out.println("  There is a " + item.get("name") + " here.");
						}
					}
				}
			}
		}
	}

	//checks if a room has a lock.
	private static boolean checkLock(Map<String, Object> location){
		List<Map<String, Object>> itemList = (List<Map<String, Object>>) location.get("items");
		for (Map<String, Object> itemAttributes : itemList){
			if (itemAttributes.get("lock") != null && (boolean)itemAttributes.get("lock")){
				return true;
			}
		} return false;
	}


	//checks if a locked room has a key that matches, "unlocking" the room.
	private static boolean isUnlocked(Map<String, Object> location){
		List<Map<String, Object>> itemList = (List<Map<String, Object>>) location.get("items");
		String key = null;
		String lock = null;

		// finds the key if an object in the location has one
		for (Map<String,Object> item : itemList){
			if (item.get("key") != null){
				key = item.get("key").toString().toLowerCase();
			}
		}

		for (Map<String, Object> item : itemList){
			if (item.get("lock") != null){
				lock = item.get("name").toString().toLowerCase();
			}
		}
		return(lock.equals(key));
	}

}