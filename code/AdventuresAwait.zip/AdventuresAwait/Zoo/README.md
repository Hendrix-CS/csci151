# A Day at the Zoo
## Summarization
In our world, the player takes place of a zoo employee whos job is to navigate the zoo and find the appropriate food for each hungry animal.

## Map
Here is a picture of our map, along with where to take certain foods.
![Map Image](Map_Image.png)

## Objective
There are five animals that must be fed, and the player must locate their food throughout the zoo. Once all animals are fed the player will have won.

## Setup
To play this map the engine must have a way to handle 'locked_longdesc' and a 'locked_desc'. The engine must also include a lock check, and check for 'unlocked_exits' that only lets the player go through these exits. It should also include the updated versions of various actions such as "GO", "LOOK", and "DROP".

