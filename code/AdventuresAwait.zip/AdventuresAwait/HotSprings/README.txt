README TEXT FILE
Garrett, Mars, Zach
LAB 9 - Text Adventure
The first two sections were copied from the videos and do not provide much surprises, but works
effectively for steps 1 and 2. Step 3 was a challenge at first, but progressively got easier. We added a HashMap
for the visited method, looking back as Dr. Goadrich pointed out, we could have used a Set instead and this would have
simplified the issue. This method was the harder of the bunch for us. After office hours we got everything working. We then
implemented a weight system for the items and max weight of 5 that could be carried by the user with statements that say
how much the inventory currently weighs in the DROP and TAKE methods. This seemed to add much more life to the game and
made it far more challenging to the user who can no longer pick up anything they want to get. It was hard on the surface,
but got progressively easier throughout along with most of the rest of lab. The final piece was the YML file we created.
Garrett lives down in HOT Springs and knows the area well, so he took on the task of making a fun little game/map
of Downtown Hot Springs. There is a goal of getting the receptionist in the Vistor Center the wedding ring from Laurey's
Diamond Center and when doing so the game is "won" and the user is awarded 5 points and a funny goal message. Another kind
of easter egg part of the game is being able to jump off the roof of the Arlington hotel at the top of the map. The user cannot
leave that area once they call up from the top hotel roof and the user is then injured and the game must be exited as there 
is no exits for this location. All of the locations were laid out very similar to real life and all the locations provided 
are real and near their actual location based on the map. It was an overall fun experience to recreate this new realistic world
and build more and more cool methods and features to add to this game.