package adventure;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import org.yaml.snakeyaml.Yaml;

/**
 * This class demonstrates how to read a YAML file using the SnakeYAML library
 * and process the resulting objects. It also demonstrates the use of the
 * Command class.
 *
 * <p>
 * Copyright 2017 Brent Yorgey. This work is licensed under a
 * <a rel="license" href= "http://creativecommons.org/licenses/by/4.0/">Creative
 * Commons Attribution 4.0 International License</a>.
 * </p>
 *
 * @author Brent Yorgey
 * @version August 21, 2017
 *
 */
public class AdventureDemo {

	public static void main(String[] args) {

		// If anything goes wrong inside the 'try' (e.g. the file is not found),
		// it will jump to the 'catch' part.
		try {

			InputStream input = new FileInputStream(new File("DowntownHotSprings.yml"));
			// Create a Yaml object to parse the .yaml file
			Yaml yaml = new Yaml();
			//Save the locations from the Yaml file
			Map<String, Object> places = new HashMap<>();
			Map<String, Object> here = null;
			Map<String, Object> looking;
			List<Map<String, Object>> inventory = new ArrayList<>();
			int myScore = 0;
			int inventoryWeight = 0;
			int inventoryMax = 5;
			boolean first = true;

			Map<String, Integer> hasVisited = new HashMap<String, Integer>();
			// Parse the .yaml file and loop over the resulting objects.
			for (Object thing : yaml.loadAll(input)) {
				Map<String, Object> location = ((Map<String, Object>) thing);
				places.put((String)location.get("id"), location);
				hasVisited.put((String)location.get("id"), 0);
				if (first) {
					here = location;
					first = false;
					hasVisited.put((String)location.get("id"), 1);
				}
			}
			printItems(here, false);
			Scanner in = new Scanner(System.in);
			Command com;
			do {
				System.out.println("");
				System.out.print("? ");
				// Read the user's input and parse it using a Command object.
				com = new Command(in.nextLine());

				// Now we can query the Command object to find out what the user
				// typed. This example only pays attention to the verb (the
				// first word typed).
				if (com.getVerb().equals(Verb.UNKNOWN)) {
					System.out.println("What?");
				} else {
					System.out.println("");
					System.out.println("OK, you want (to) " + com.getVerb() + ".");
					System.out.println("");

					if (com.getVerb() == Verb.GO) {
						Map<String, Object> exits = (Map<String, Object>) here.get("exits");
						String newID = (String)exits.get(com.getDirection().toString().toLowerCase());
						if (newID != null) {

							if (places.containsKey(newID)) {
								here = (Map<String, Object>) places.get(newID);
								printItems(here, hasVisited.get(newID) != 0);
								hasVisited.replace(newID, 1);
							} else {
								System.out.println("That location looks hazy, avoid it and stay here.");
							}
						} else {
							System.out.println("You can't go that way.");
						}
					} else if (com.getVerb() == Verb.TAKE) {
						List<Map<String, Object>> itemList = (List<Map<String, Object>>)here.get("items");
						Map<String, Object> item = findItem(itemList, com.getNoun());
						if (item == null) {
							item = aliasFinder(itemList, com.getNoun());
						}
						if (item != null) {
							Boolean portable = (Boolean) item.get("portable");
							if (portable != null) {
								System.out.println("You can't take the " + com.getNoun() + "!");
							} else {
								if (item.get("weight") != null) {
									inventoryWeight += (Integer)item.get("weight");
									if (inventoryWeight > inventoryMax) {
										System.out.println("You can't pick up this item. Your inventory would be bigger than the most you can carry of " + inventoryMax + " pounds.");
									} else {
										itemList.remove(item);
										inventory.add(item);
										System.out.println("You took the " + com.getNoun() + ".");
										System.out.println("You are carrying " + inventoryWeight + " pound(s) in weight");
										if (item.containsKey("goal") && item.get("goal").equals(here.get("id"))) {
											System.out.println("You removed the " + item.get("name") + " from its home.");
											myScore -= (Integer) item.get("score");
										}
									}
								} else {
										System.out.println(item.get("name") + " has no weight and cannot be taken");
									}
							}
						} else {
							System.out.println("There is no " + com.getNoun() + " here.");
						}

					} else if (com.getVerb() == Verb.INVENTORY) {
						if (inventory.size() > 0) {
					    	System.out.println("You are carrying:");
                            for (Map<String, Object> itemAttributes : inventory) {
                                System.out.println("a(n) " + itemAttributes.get("name"));
                            }
                        } else {
					        System.out.println("You have no items in your inventory");
                        }
                    } else if (com.getVerb() == Verb.DROP) {
					    Map<String, Object> item = findItem(inventory, com.getNoun());
						if (item == null) {
							item = aliasFinder(inventory, com.getNoun());
						}
					    if (item != null) {
					        inventory.remove(item);
                            List<Map<String, Object>> itemList = (List<Map<String, Object>>) here.get("items");
                            if (itemList == null) {
                                itemList = new ArrayList<>();
                                here.put("items", itemList);
                            }
                            itemList.add(item);
                            System.out.println("You dropped the " + item.get("name") + ".");
							inventoryWeight -= (Integer)item.get("weight");
							System.out.println("You are carrying " + inventoryWeight + " pound(s) in weight");
                            if (item.get("goal") != null) {
								if (item.get("goal").equals(here.get("id"))) {
									System.out.println(item.get("goalmessage"));
									myScore += (Integer) item.get("score");
								}
							}

                        } else {
					        System.out.println("You don't have a " + com.getNoun().toLowerCase());
                        }
                    } else if (com.getVerb() == Verb.SCORE) {
						System.out.println("Your score is " + myScore + ".");
					} else if (com.getVerb() == Verb.LOOK) {
						List<Map<String, Object>> itemList = (List<Map<String, Object>>)here.get("items");
						Map<String, Object> exits = (Map<String, Object>)here.get("exits");
						if (com.getNoun().equals("") && (exits.containsKey(com.getDirection().toString().toLowerCase()))) {
							String newID = (String) exits.get(com.getDirection().toString().toLowerCase());
							if (newID != null) {
								if (places.containsKey(newID)) {
									looking = (Map<String, Object>) places.get(newID);
									System.out.println("There is a " + looking.get("name").toString().toLowerCase() + " in that direction.");
								}
							}
						} else if (com.getNoun() != null && !com.getNoun().equals("")) {
							Map<String, Object> item = findItem(itemList, com.getNoun());
							if (item == null) {
								item = aliasFinder(itemList, com.getNoun());
							}
							Map<String, Object> inventoryItem = findItem(inventory, com.getNoun());
							if (inventoryItem == null) {
								inventoryItem = aliasFinder(inventory, com.getNoun());
							}
							if (item != null) {
								System.out.println(item.get("desc"));

							} else if (inventoryItem != null) {
								System.out.println(inventoryItem.get("desc"));

							} else if (com.getNoun() != null) {
								System.out.println("I don't see a " + com.getNoun() + " here");
							}
						}else {
							if (com.getDirection().equals(Direction.UNKNOWN)) {
								printItems(here, false);
							} else {
								System.out.print("There's nothing to see that way.");
							}
						}
					} else if (com.getVerb() == Verb.HELP) {
						System.out.println("Explore your surroundings.  You can get points by taking certain\n" +
								"      objects to certain other locations.\n" +
								"\n" +
								"    Available commands:\n" +
								"      go <dir>        - move in a certain direction\n" +
								"      look            - look at your surroundings\n" +
								"      look <dir>      - see what location lies in a given direction\n" +
								"      look [at] <obj> - look at an object in your location or inventory\n" +
								"      take <obj>      - pick up an object\n" +
								"      drop <obj>      - put down an object\n" +
								"      inventory       - see what you are carrying\n" +
								"      score           - see your current score\n" +
								"      help            - show this help message\n" +
								"      quit            - quit\n" +
								"\n" +
								"    Available directions:\n" +
								"      north, south, east, west, northeast, northwest, southeast, southwest, up, down, and out");

					}
				}
			} while (com.getVerb() != Verb.QUIT);
			in.close();

		} catch (IOException e) {
			// This is what to do if anything goes wrong, e.g. the file
			// Hendrix.yaml is not found. Just print the error and quit.
			System.out.println(e);
			System.exit(1);
		}
	}

    private static Map<String, Object> findItem(List<Map<String, Object>> itemList, String what) {
	    if (itemList != null) {
            for (Map<String, Object> itemAttributes : itemList) {
                if (((String) itemAttributes.get("name")).toLowerCase().equals(what.toLowerCase())) {
                    return itemAttributes;
                }
            }
        }
        return null;
    }


        /**
         * Take a key-value mapping representing a location in the world. Look
         * through it and print any items it contains.
         *
         * @param location
         *            The key-value mapping representing the location.
         */
	private static void printItems(Map<String, Object> location, boolean visited) {

		//If the place has been visited or not
		if (visited) {
			System.out.println(location.get("desc"));
		} else {
			System.out.println(location.get("longdesc"));
		}

		// Extract the list of items, which is stored under the key "items".
		// Each item is itself a key-value mapping.
		List<Map<String, Object>> itemList = (List<Map<String, Object>>)location.get("items");

		// If the location does not have a key called "items", then the call to
		// get("items") above will return null.
		if (itemList != null) {


			// For each item, get the values associated to the keys "name" and
			// "portable".
			for (Map<String, Object> itemAttributes : itemList) {
				Boolean portable = (Boolean) itemAttributes.get("portable");
				if (portable == null) {
					System.out.print("There is a(n) " + itemAttributes.get("name") + " here.");
					System.out.println("");
				}
				// Cast the "portable" value to a Boolean (not boolean) since
				// Boolean is an object type and can be null. If there is no
				// "portable" key then the result will be null and we can check
				// for that case. If we had used boolean instead, it would crash
				// when the key "portable" does not exist.

				// Items are portable by default.  They are non-portable only
				// if the "portable" key exists and has the value false.
			}
		}
	}
	private static Map<String, Object> aliasFinder(List<Map<String, Object>> itemList, String com) {
		List<Map<String, Object>> aliasList = null;
		//goes through itemList
		for (Map<String, Object> checkItem : itemList) {
			//asks if has any aliases
			if (checkItem.containsKey("aliases")) {
				// makes aliasList a list of aliases for current checkItem
				aliasList = (List<Map<String, Object>>)checkItem.get("aliases");
				//Asks if what user said in an alias in the item the code is looking at
				if (aliasList.contains(com)) {
					return checkItem;
				}
			}
		}
		//if what user gave as item was not an alias, keep item null
		return null;
	}
}