    There is an Imposter Among Us.

    Code by
    Matthew Kalahiki
    Samantha Huckabay
    Cameron Minor

    Our group set out on creating a text based adventure game based off of the popular video
    game: Among Us. Given that Among Us has relatively small maps with rooms connected to each
    other by various hallways, it seemed like a great layout for a yml map. Additionally, the
    game contains various tasks and objects in each room, some of which require you to transfer
    items to different rooms, which perfectly fit the score system already in place in the engine
    we coded for the base lab.

    The major changes we implemented come in the form of additional non-player characters. These
    characters roam around the map, have unique interactions in every room, and since one player
    is the imposter, you may start seeing other players killed off.
    -   Our yml for the map, Skeld, now has a list of character interactions in each room, similarly
        formatted to the items list.
    -   The look verb now enables the player to look at another character in order to observe suspicous
        activity.
    -   The go verb now sends each character in a random direction. If that direction is not valid for
        that room, they will simply stay put, creating the illusion of characters spending time in
        various rooms, like they would in the game.
    -   The new locate verb allows the player to see the location of all characters on the ship,
        and even check if any players are dead.
    -   The new report verb allows the player to report that a player has died as long as the
        player is in the cafeteria when they report.
    -   Once a body is reported, the player can vote who they believe the imposter to be. The player's
        vote is very powerful, because NPCs will vote with you.
    -   There is a win condition if the imposter is voted off, and a lose condition if the imposter
        kills enough players.

    These are the main changes we took in our code. The changes we made relied heavily on changes in
    the AdventureDemo itself. Whole methods may need to be copied over to allow full functionality.
    Because we implemented so many mechanic changes, sections like look and go were drastically changed,
    and a variety of additional variables get initialized at the beginning of main. Using our code for
    AdventureDemo and the Skeld.yml file, you should be able to enjoy a text-based version of Among Us.