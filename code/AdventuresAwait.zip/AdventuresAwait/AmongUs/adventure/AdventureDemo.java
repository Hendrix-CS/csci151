package adventure;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import org.yaml.snakeyaml.Yaml;

/**
 * This class demonstrates how to read a YAML file using the SnakeYAML library
 * and process the resulting objects. It also demonstrates the use of the
 * Command class.
 *
 * <p>
 * Copyright 2017 Brent Yorgey. This work is licensed under a
 * <a rel="license" href= "http://creativecommons.org/licenses/by/4.0/">Creative
 * Commons Attribution 4.0 International License</a>.
 * </p>
 *
 * @author Brent Yorgey
 * @version August 21, 2017
 *
 */
public class AdventureDemo {

	public static void main(String[] args) {

		// If anything goes wrong inside the 'try' (e.g. the file is not found),
		// it will jump to the 'catch' part.
		try {

			InputStream input = new FileInputStream(new File("Skeld.yml"));

			// Create a Yaml object to parse the .yaml file
			Yaml yaml = new Yaml();

			Map<String, Object>places = new HashMap<String, Object>();

			Map<String, Object>here = null;

			List<Map<String, Object>> inventory = new ArrayList<Map<String, Object>>();

			boolean first = true;

			Set<String> visitedPlaces = new HashSet<String>();

			int score = 0;

			List<Map<String, Object>>charLocations = new ArrayList<Map<String, Object>>();

			String[]colors = new String[]{"blue","red","black","green"};

			Set<String>deadChars = new HashSet<String>();

			boolean[]isDead = new boolean[colors.length];

			boolean[]wasReported = new boolean[colors.length];

			Set<String> colorSet = new HashSet<String>();

			Random r = new Random();
			int impostor = r.nextInt(colors.length);


			for (int i = 0; i < colors.length; i++){
				colorSet.add(colors[i]);
			}

			// Parse the .yaml file and loop over the resulting objects.
			for (Object thing : yaml.loadAll(input)) {

				Map<String, Object>location = (Map<String, Object>)thing;
				places.put((String)location.get("id"),location);

				if(first){
					here = location;
					first = false;
				}
			}

			for(int i = 0;i < colors.length;i++){
				charLocations.add(here);
				isDead[i] = false;
				wasReported[i] = false;
			}
			printItems(here,!visitedPlaces.contains((String)here.get("id")));
			printCharacters(charLocations,colors,isDead,here,wasReported);
			visitedPlaces.add((String)here.get("id"));

			Scanner in = new Scanner(System.in);
			Command com;

			do {
				System.out.print("? ");

				// Read the user's input and parse it using a Command object.
				com = new Command(in.nextLine());

				// Now we can query the Command object to find out what the user
				// typed. This example only pays attention to the verb (the
				// first word typed).
				if (com.getVerb().equals(Verb.UNKNOWN)) {
					System.out.println("What?");
				} else {
					System.out.println("OK, you want to " + com.getVerb() + ".");

					if (com.getVerb() == Verb.GO) {

						Map<String, Object> exits = (Map<String, Object>) here.get("exits");

						String newID = (String) exits.get(com.getDirection().toString().toLowerCase());

						if (newID != null) {

							if (places.containsKey(newID)) {

								here = (Map<String, Object>) places.get(newID);
								printItems(here, !visitedPlaces.contains((String) here.get("id")));
								if (!visitedPlaces.contains((String) here.get("id"))) {
									visitedPlaces.add((String) here.get("id"));
								}


							} else {
								System.out.println("That location looks hazy, you avoid it and stay here.");
							}
						} else {
							System.out.println("You can't go that way.");
						}
						for(int i = 0; i < colors.length; i++){

							Random newRand = new Random();

							Direction randDirection = Direction.values()[newRand.nextInt(Direction.values().length)];

							Map<String, Object> charExits = (Map<String, Object>) charLocations.get(i).get("exits");

							String charNewID = (String) charExits.get(randDirection.toString().toLowerCase());

							int d = 0;

							for(int j = 0;j < isDead.length;j++){
								if(isDead[j] == true){
									d++;
								}
							}

							if(d < colors.length - 1 && !isDead[impostor]) {
								if (Math.random() >= .98 && i != impostor) {
									deadChars.add(colors[i]);
									isDead[i] = true;
								}
							}
							if (d == colors.length - 1){
								if(!isDead[impostor]) {
									com = new Command("quit");
								}
							}
							if(!isDead[i]) {

								if (charNewID != null) {

									if (places.containsKey(charNewID)) {

										charLocations.set(i, (Map<String, Object>) places.get(charNewID));
									}
								}
							}
						}
						printCharacters(charLocations,colors,isDead,here,wasReported);
					} else if (com.getVerb() == Verb.TAKE) {

						List<Map<String, Object>> itemList = (List<Map<String, Object>>) here.get("items");

						Map<String, Object> item = findItem(itemList, com.getNoun());
						if (item != null) {
							if(item.get("portable") != null && !(boolean)item.get("portable")) {
								System.out.println("You can't take that!");
							}else{
								itemList.remove(item);
								inventory.add(item);
								System.out.println("Taken.");
							}
						} else {
							System.out.println("There is no " + com.getNoun() + " here.");
						}


					} else if (com.getVerb() == Verb.INVENTORY) {
						if (inventory.size() > 0) {

							for (Map<String, Object> itemAttributes : inventory) {
								System.out.println(itemAttributes.get("name"));
							}

						} else {
							System.out.println("You have no items in your inventory.");
						}
					} else if (com.getVerb() == Verb.DROP) {

						Map<String, Object> item = findItem(inventory, com.getNoun());
						if (item != null) {
							inventory.remove(item);
							List<Map<String, Object>> itemList = (List<Map<String, Object>>) here.get("items");
							if (itemList == null) {
								itemList = new ArrayList<Map<String, Object>>();
								here.put("items", itemList);
							}
							itemList.add(item);
							if (item.get("goal") != null) {
								if (here.get("id").equals(item.get("goal"))) {
									score += (int) item.get("score");
									System.out.println(item.get("goalmessage"));
									itemList.remove(item);
								}
							}
						} else {
							System.out.println("You don't have a " + com.getNoun());
						}
					} else if (com.getVerb() == Verb.SCORE) {
						System.out.println(score);
					} else if (com.getVerb() == Verb.LOOK) {

						if (!(com.getNoun().equals(""))) {
							List<Map<String, Object>> itemList = (List<Map<String, Object>>) here.get("items");
							Map<String, Object> item = findItem(itemList, com.getNoun());
							List<Map<String, Object>> colorList = (List<Map<String, Object>>) here.get("characters");


							if (item == null) {
								item = findItem(inventory, com.getNoun());
							}
							if (item == null && colorSet.contains(com.getNoun().toLowerCase())){
								boolean inRoom = false;
								for(int i = 0; i < colors.length; i++){
									if (colors[i].equals(com.getNoun().toLowerCase())){
										if(isDead[i]){
											System.out.println(colors[i] + " is dead!");
											inRoom = true;
										}else if (charLocations.get(i).equals(here)){
											System.out.println(colorList.get(i).get("desc"));
											inRoom = true;
										}
									}
								}
								if (!inRoom){System.out.println("This character is not in the room.");}
							}
							else if (item != null) {
								System.out.println(item.get("desc"));
							} else {
								System.out.println("You don't see this item.");
							}
						} else if (com.getDirection() != Direction.UNKNOWN) {

							Map<String, Object> exits = (Map<String, Object>) here.get("exits");

							String newID = (String) exits.get(com.getDirection().toString().toLowerCase());

							if (newID != null) {

								if (places.containsKey(newID)) {

									System.out.println("You can see " + printName((Map<String, Object>) places.get(newID)) + " in that direction");

								} else {
									System.out.println("There's a bunch of haziness that way.");
								}

							} else {
								System.out.println("There's nothing to see that way.");
							}
						}else {
							System.out.println(here.get("longdesc"));
						}
					}else if(com.getVerb() == Verb.HELP){
						System.out.println(" Explore your surroundings.  You can get points by taking certain\n" +
								"      objects to certain other locations.\n" +
								"\n" +
								"    Available commands:\n" +
								"      go <dir>        - move in a certain direction\n" +
								"      look            - look at your surroundings\n" +
								"      look <dir>      - see what location lies in a given direction\n" +
								"      look [at] <obj> - look at an object in your location or inventory\n" +
								"      look [at] <clr> - look at a character of that color\n" +
								"      take <obj>      - pick up an object\n" +
								"      drop <obj>      - put down an object\n" +
								"      inventory       - see what you are carrying\n" +
								"      score           - see your current score\n" +
								"      help            - show this help message\n" +
								"      quit            - quit\n" +
								"	   locate		   - shows the locations of all characters\n" +
								"      report          - if used in the cafeteria, can report a dead body\n" +
								"\n" +
								"    Available directions:\n" +
								"      north south east west northeast northwest southeast southwest up down in out");
					}else if(com.getVerb() == Verb.LOCATE){
						for(int i = 0; i < colors.length; i++){
							if(isDead[i] && !wasReported[i]){
								System.out.println(colors[i] + " died in " + (String)charLocations.get(i).get("name"));
							}else if (!isDead[i]) {
								System.out.println(colors[i] + " ; " + (String) charLocations.get(i).get("name"));
							}
						}
					}else if(com.getVerb() == Verb.REPORT){
							boolean a = false;
							int d = 0;
							for(int i = 0; i < colors.length; i ++){
								if (isDead[i] && !wasReported[i]) {
									a = true;
								}
							}

						for(int j = 0;j < isDead.length;j++){
							if(isDead[j] == true){
								d++;
							}
						}
						if(!isDead[impostor]) {

							if (((String) here.get("id")).equals("caf")) {
								if (a) {
									boolean hasVoted = false;
									for(int k = 0; k < colors.length;k++){
										if(isDead[k] && !wasReported[k]){
											wasReported[k] = true;
										}
									}
									while (!hasVoted) {

										Set<String> voters = new HashSet<String>();
										System.out.println("You can vote for:");
										for (int i = 0; i < colors.length; i++) {
											if (!isDead[i]) {
												voters.add(colors[i]);
												System.out.println(colors[i]);
											}
										}
										System.out.println("Who would you like to vote for?");
										Scanner scan = new Scanner(System.in);
										String vote = scan.next();
										if (voters.contains(vote.toLowerCase())) {
											for (int i = 0; i < colors.length; i++) {
												if (colors[i].equals(vote.toLowerCase())) {
													isDead[i] = true;
													wasReported[i] = true;
													if(i == impostor){
														System.out.println(colors[i] + " was the impostor.");
														System.out.println("Congratulations! You found the imposter!");
														com = new Command("quit");
													}else {
														System.out.println(colors[i] + " was not the impostor.");
														d++;
														if (d == colors.length - 1){
															if(!isDead[impostor]) {
																System.out.println("Unfortunately the imposter outnumbers the innocent.");
																com = new Command("quit");
															}
														}
													}
												}
											}
											hasVoted = true;
										} else {
											System.out.println("You can't vote for this person");
										}

									}
								} else {
									System.out.println("You can't report right now.");
								}
							} else {
								System.out.println("You can't report here.");
							}
						}else{
							System.out.println("The impostor is already dead.");
						}
					}
				}
			} while (com.getVerb() != Verb.QUIT);

			in.close();
			System.out.println("The impostor won.");

		} catch (IOException e) {
			// This is what to do if anything goes wrong, e.g. the file
			// Hendrix.yaml is not found. Just print the error and quit.
			System.out.println(e);
			System.exit(1);
		}
	}

	private static Map<String, Object>findItem(List<Map<String, Object>>itemList,String what){
		if(itemList != null) {
			ArrayList<String>a = new ArrayList<>();
			for (Map<String, Object> itemAttributes : itemList) {
				if(itemAttributes.containsKey("aliases")){
					a = (ArrayList<String>)itemAttributes.get("aliases");
				}
				if (((String) itemAttributes.get("name")).toLowerCase().equals(what.toLowerCase()) || a.contains(what.toLowerCase())) {
					return itemAttributes;
				}
			}
		}
		return null;
	}

	/**
	 * Take a key-value mapping representing a location in the world. Look
	 * through it and print any items it contains.
	 *
	 * @param location
	 *            The key-value mapping representing the location.
	 */
	private static void printItems(Map<String, Object> location,boolean a) {
		if (a) {
			System.out.println(location.get("longdesc"));
		}else{
			System.out.println(location.get("desc"));
		}

		// Extract the list of items, which is stored under the key "items".
		// Each item is itself a key-value mapping.
		List<Map<String, Object>> itemList = (List<Map<String, Object>>) location.get("items");

		// If the location does not have a key called "items", then the call to
		// get("items") above will return null.
		if (itemList != null) {

			// For each item, get the values associated to the keys "name" and
			// "portable".
			for (Map<String, Object> itemAttributes : itemList) {

				// Cast the "portable" value to a Boolean (not boolean) since
				// Boolean is an object type and can be null. If there is no
				// "portable" key then the result will be null and we can check
				// for that case. If we had used boolean instead, it would crash
				// when the key "portable" does not exist.
				Boolean portable = (Boolean) itemAttributes.get("portable");

				// Items are portable by default.  They are non-portable only
				// if the "portable" key exists and has the value false.
				if (portable != null && !portable) {
					System.out.print("");
				} else {
					System.out.println("  " + itemAttributes.get("name"));
				}
			}
		}
	}
	private static String printName(Map<String, Object> location){

		if(location.containsKey("article")){
			return location.get("article") + " " + location.get("name").toString().toLowerCase();
		}
			return (String)location.get("name");


	}
	private static void printCharacters(List<Map<String, Object>> charLocation, String[]colors,boolean[]isDead,Map<String, Object>here, boolean[]wasReported){
		for(int i = 0; i < colors.length; i ++){
			if (charLocation.get(i).equals(here) && !wasReported[i]){
				if(isDead[i]){
					System.out.println(colors[i] + " is dead!.");
				}else{
					System.out.println(colors[i] + " is here.");
				}
			}
		}
	}

}