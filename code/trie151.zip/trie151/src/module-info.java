module trie151 {
    requires javafx.fxml;
    requires javafx.controls;
    requires junit;

    exports trie.core;
    opens trie.gui;
}