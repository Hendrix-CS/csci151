package maze.searchers;

public class ListQueue<E> implements Queue<E> {

    // TODO Step 1 Add fields

    @Override
    public void add(E data) {
        // TODO Step 1
    }

    @Override
    public E remove() {
        // TODO Step 1
        return null;
    }

    @Override
    public E element() {
        // TODO Step 1
        return null;
    }
    @Override
    public int size() {
        // TODO Step 1
        return 0;
    }

    @Override
    public int capacity() {
        return size();
    }

}
