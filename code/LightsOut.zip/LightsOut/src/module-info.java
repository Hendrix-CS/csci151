module LightsOut {
    requires javafx.fxml;
    requires javafx.controls;
    exports games;
    opens games;
}