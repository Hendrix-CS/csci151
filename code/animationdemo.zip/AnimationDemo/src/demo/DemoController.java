package demo;

import java.util.ArrayList;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class DemoController {

	@FXML
	private Pane pane;

	private ArrayList<Ball> juggling;

	private Movement clock;

	private class Movement extends AnimationTimer {

		private long FRAMES_PER_SEC = 50L;
		private long INTERVAL = 1000000000L / FRAMES_PER_SEC;

		private long last = 0;
		private ArrayList<Ball> bs;

		public void setBalls(ArrayList<Ball> bs) {
			this.bs = bs;
		}

		@Override
		public void handle(long now) {
			if (now - last > INTERVAL) {
				for (Ball b : bs) {
					b.move();
					b.draw();
				}
				last = now;
			}
		}
	}

	@FXML
	public void initialize() {
		juggling = new ArrayList<Ball>();

		for (int i = 0; i < 5; i++) {
			makeCircle();
		}

		clock = new Movement();
		clock.setBalls(juggling);
		clock.start();
	}

	private void makeCircle() {
		Circle c = new Circle();
		c.setFill(Color.GREEN);
		c.setStroke(Color.BLACK);
		c.setOnMouseDragged(event -> drag(event));
		c.setOnMousePressed(event -> pressed(event));
		c.setOnMouseReleased(event -> released(event));
		juggling.add(new Ball(25, c, pane));
		pane.getChildren().add(c);
	}

	// What to do when the mouse is Pressed
	private void pressed(MouseEvent event) {
		Ball b = findBall((Node) event.getSource());
		if (b != null) {
			b.toggleMovement();
			b.setColor(Color.DARKRED);
		}
	}

	// What to do when the mouse is Released
	private void released(MouseEvent event) {
		Ball b = findBall((Node) event.getSource());
		if (b != null) {
			b.toggleMovement();
			b.setColor(Color.DODGERBLUE);
		}
	}

	// What to do when the mouse is Dragged
	private void drag(MouseEvent event) {
		Ball b = findBall((Node) event.getSource());
		if (b != null) {
			b.setX(b.getX() + event.getX());
			b.setY(b.getY() + event.getY());
			b.draw();
		}
	}

	// Look for the ball associated with a Node
	private Ball findBall(Node n) {
		for (Ball b : juggling) {
			if (b.getCircle().equals(n)) {
				return b;
			}
		}
		return null;
	}
}
