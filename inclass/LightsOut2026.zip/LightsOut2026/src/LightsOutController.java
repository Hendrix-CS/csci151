import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

public class LightsOutController {

    // Data Members
    // VIEW
    @FXML
    private Button button;
    @FXML
    private Pane pane;
    @FXML
    private Label label;

    private Movement clock;

    private class Movement extends AnimationTimer {

        private final long FRAMES_PER_SEC = 8L;
        private final long INTERVAL = 1000000000L / FRAMES_PER_SEC;

        private long last = 0;

        @Override
        public void handle(long now) {
            if (now - last > INTERVAL) {
                seconds++;
                updateViews();
                last = now;
            }
        }
    }


    // MODEL
    private LightsOut game;
    private LightsOutView lov;
    private int seconds;

    // Constructor
    public void initialize() {
        game = new LightsOut(5);
        lov = new LightsOutView(game, this);
        pane.getChildren().clear();
        pane.getChildren().add(lov);
        clock = new Movement();
        clock.start();
        updateViews();
    }

    public void reset() {
        game = new LightsOut(5);
        lov = new LightsOutView(game, this);
        pane.getChildren().clear();
        pane.getChildren().add(lov);
        seconds = 0;
        updateViews();
    }

    // Methods
    public void updateViews() {
        lov.update(pane.getWidth(), pane.getHeight());
        int sec = seconds % 60;
        label.setText("Time: " + (seconds / 60) + ":" + (sec < 10 ? "0" : "") + sec);
    }

}
