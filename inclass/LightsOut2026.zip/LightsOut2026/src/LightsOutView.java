import javafx.scene.Parent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class LightsOutView extends Parent {

    private LightsOut game;
    private Rectangle[][] grid;
    private LightsOutController loc;

    public LightsOutView(LightsOut game, LightsOutController loc) {
        this.game = game;
        this.loc = loc;
        this.grid = new Rectangle[game.getSize()][game.getSize()];
    }

    public void update(double width, double height) {
        getChildren().clear();
        int size = game.getSize();

        double cellWidth = width / size;
        double cellHeight = height / size;

        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                Rectangle cell = new Rectangle(x * cellWidth,
                        y * cellHeight, cellWidth, cellHeight);
                cell.setFill(game.getState(y, x).getColor());
                cell.setStroke(Color.BLACK);

                Position p = new Position(x, y);
                cell.setOnMouseClicked(event -> {
                    game.toggle(p.y(), p.x());
                    loc.updateViews();
                });

                getChildren().add(cell);
            }
        }
    }
}
